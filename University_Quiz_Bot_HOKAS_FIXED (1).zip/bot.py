from handlers.bot import build_application
from database import init_db

if __name__ == "__main__":
    init_db()
    build_application().run_polling(drop_pending_updates=True)
